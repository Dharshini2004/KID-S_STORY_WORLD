package com.example.storybookbackend.Model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Story {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int storyId;

    private String storyText;

    // @OneToOne
    // @JsonBackReference
    // @JoinColumn(name = "book_id", referencedColumnName = "bookId", nullable = false)
    // private Book book;


    // @OneToMany(mappedBy = "story", cascade = CascadeType.ALL, orphanRemoval = true)
    // @JsonManagedReference
    // private List<Quiz> quizs = new ArrayList<>();

    public Story() {
    }
    public Story(int storyId, String storyText) {
        this.storyId = storyId;
        this.storyText = storyText;
        // this.book = book;
    }



    public int getStoryId() {
        return storyId;
    }

    public void setStoryId(int storyId) {
        this.storyId = storyId;
    }

    public String getStoryText() {
        return storyText;
    }

    public void setStoryText(String storyText) {
        this.storyText = storyText;
    }

    // public Book getBook() {
    //     return book;
    // }

    // public void setBook(Book book) {
    //     this.book = book;
    // }



}
