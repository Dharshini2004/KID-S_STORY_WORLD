package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.User;
import com.example.storybookbackend.Service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    UserService userDetailsService;

    //post
    @CrossOrigin(origins = "http://localhost:5173")
    @PostMapping("/add")
    public ResponseEntity<User> addUserData( @RequestBody User userDetails)
    {
        User ud=userDetailsService.createUserDetails(userDetails);
        return new ResponseEntity<>(ud,HttpStatus.CREATED);
    }
    //get
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get")
    public ResponseEntity<java.util.List<User>> showuserData()
    {
        return new ResponseEntity<>(userDetailsService.getUserDetails(),HttpStatus.OK);
    }
    
    //getbyid
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get/{id}")
    public User getUserById(@PathVariable int id) {
        return userDetailsService.getUserById(id);
    }

    //UPDATE
    @CrossOrigin(origins = "http://localhost:5173")
    @PutMapping("/put/{id}")
    public ResponseEntity<User> updateUserDetails(@PathVariable("id") int id,@RequestBody User userDetails )
    {   
        if(userDetailsService.updateUserDetails(id, userDetails)==true)
        {

            return new ResponseEntity<>(userDetails,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @CrossOrigin(origins = "http://localhost:5173")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteuserdata(@PathVariable("id") int id)
    {
        if(userDetailsService.deleteUserDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
