package com.example.storybookbackend.enums;

public enum TokenType {
    BEARER
}
