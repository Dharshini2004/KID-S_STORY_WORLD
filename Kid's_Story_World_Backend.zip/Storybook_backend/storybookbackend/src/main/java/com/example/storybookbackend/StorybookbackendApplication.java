package com.example.storybookbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StorybookbackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(StorybookbackendApplication.class, args);
	}

}
