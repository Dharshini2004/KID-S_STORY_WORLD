package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Model.User;
import com.example.storybookbackend.Service.StoryService;

@RestController
@RequestMapping("/api/story")
public class StoryController {
     @Autowired
    StoryService storyService;

    //post
    @PostMapping("/add")
    public ResponseEntity<Story> addStory(@RequestBody Story story)
    {
        Story b=storyService.createStoryDetails(story);
        return new ResponseEntity<>(b,HttpStatus.CREATED);
    }

    //get
    @GetMapping("/get")
    public ResponseEntity<java.util.List<Story>> showStorydetails()
    {
        return new ResponseEntity<>(storyService.getStoryDetails(),HttpStatus.OK);
    }

    //getbyid
    @GetMapping("/get/{id}")
    public Story getStoryById(@PathVariable int id) {
        return storyService.getStoryById(id);
    }

    //UPDATE
    @PutMapping("/put/{id}") 
    public ResponseEntity<Story> updateStoryDetails(@PathVariable("id") int id,@RequestBody Story story )
    {   
        if(storyService.updateStoryDetails(id, story)==true)
        {

            return new ResponseEntity<>(story,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteStorydata(@PathVariable("id") int id)
    {
        if(storyService.deleteStoryDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
