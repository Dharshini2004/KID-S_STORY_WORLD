package com.example.storybookbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.storybookbackend.Model.Feedback;
import com.example.storybookbackend.Model.Story;
import com.example.storybookbackend.Service.FeedbackService;

@RestController
@RequestMapping("/api/feedback")
public class FeedbackController {
     @Autowired
    FeedbackService feedbackService;

    //post
    @CrossOrigin(origins = "http://localhost:5173")
    @PostMapping("/add")
    public ResponseEntity<Feedback> addfeedback(@RequestBody Feedback feedback)
    {
        Feedback b=feedbackService.createFeedbackDetails(feedback);
        return new ResponseEntity<>(b,HttpStatus.CREATED);
    }

    //get
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get")
    public ResponseEntity<java.util.List<Feedback>> showbookdetails()
    {
        return new ResponseEntity<>(feedbackService.getFeedbackDetails(),HttpStatus.OK);
    }

    //getbyid
    @CrossOrigin(origins = "http://localhost:5173")
    @GetMapping("/get/{id}")
    public Feedback getFeedbackById(@PathVariable int id) {
        return feedbackService.getFeedbackById(id);
    }

    //UPDATE
    @CrossOrigin(origins = "http://localhost:5173")
    @PutMapping("/put/{id}")
    public ResponseEntity<Feedback> updateUserDetails(@PathVariable("id") int id,@RequestBody Feedback feedback )
    {   
        if(feedbackService.updateFeedbackDetails(id, feedback)==true)
        {

            return new ResponseEntity<>(feedback,HttpStatus.OK);
        }
        return new ResponseEntity<>(null,HttpStatus.NOT_FOUND);
    }

    //DELETE
    @CrossOrigin(origins = "http://localhost:5173")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteuserdata(@PathVariable("id") int id)
    {
        if(feedbackService.deleteFeedbackDetails(id)==true)
        {
            return new ResponseEntity<>(true,HttpStatus.OK);
        }
        return new ResponseEntity<>(false,HttpStatus.NOT_FOUND);
    }
}
