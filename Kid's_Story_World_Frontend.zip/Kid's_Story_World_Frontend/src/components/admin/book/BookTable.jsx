import React from 'react';
import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton } from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';

const BookTable = ({ onEdit, onDelete, books }) => {
  return (
    <Box p={3}>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Title</TableCell>
              <TableCell>Author</TableCell>
              <TableCell>Description</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {books.map((book) => (
              <TableRow key={book.bookId}>
                <TableCell>{book.title}</TableCell>
                <TableCell>{book.author}</TableCell>
                <TableCell>{book.description}</TableCell>
                <TableCell>
                  <IconButton onClick={() => onEdit(book)}>
                    <Edit />
                  </IconButton>
                  <IconButton edge="end" onClick={() => onDelete(book.bookId)}>
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default BookTable;


// import React, { useEffect, useState } from 'react';
// import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton } from '@mui/material';
// import { Edit, Delete } from '@mui/icons-material';
// import axios from 'axios';

// const BookTable = ({ onEdit, onDelete }) => {
//   const [books, setBooks] = useState([]);

//   useEffect(() => {
//     const fetchBooks = async () => {
//       try {
//         const token = localStorage.getItem('token');
//         const response = await axios.get('http://localhost:8080/api/books/get', {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setBooks(response.data);
//       } catch (error) {
//         console.error('Error fetching books:', error);
//       }
//     };

//     fetchBooks();
//   }, []);

//   return (
//     <Box p={3}>
//       <TableContainer component={Paper}>
//         <Table>
//           <TableHead>
//             <TableRow>
//               <TableCell>Title</TableCell>
//               <TableCell>Author</TableCell>
//               <TableCell>Description</TableCell>
//               <TableCell>Actions</TableCell>
//             </TableRow>
//           </TableHead>
//           <TableBody>
//             {books.map((book) => (
//               <TableRow key={book.bookId}>
//                 <TableCell>{book.title}</TableCell>
//                 <TableCell>{book.author}</TableCell>
//                 <TableCell>{book.description}</TableCell>
//                 <TableCell>
//                   <IconButton onClick={() => onEdit(book)}>
//                     <Edit />
//                   </IconButton>
//                   <IconButton edge="end" onClick={() => onDelete(book.bookId)}>
//                     <Delete />
//                   </IconButton>
//                 </TableCell>
//               </TableRow>
//             ))}
//           </TableBody>
//         </Table>
//       </TableContainer>
//     </Box>
//   );
// };

// export default BookTable;


