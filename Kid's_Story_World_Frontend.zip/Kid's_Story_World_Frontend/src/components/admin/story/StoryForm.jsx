import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, Typography } from '@mui/material';

const StoryForm = ({ onSubmit, story }) => {
  const [storyText, setStoryText] = useState(story ? story.storyText : '');

  useEffect(() => {
    if (story) {
      setStoryText(story.storyText);
    }
  }, [story]);

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      storyId: story ? story.storyId : null, // Include storyId if updating
      storyText,
    });
    setStoryText('');
  };

  return (
    <Box component="form" onSubmit={handleSubmit} p={3}>
      <Typography variant="h5">{story ? 'Update Story' : 'Add Story'}</Typography>
      <TextField
        label="Story Text"
        value={storyText}
        onChange={(e) => setStoryText(e.target.value)}
        fullWidth
        margin="normal"
        multiline
        rows={4}
        required
      />
      <Box mt={3}>
        <Button type="submit" variant="contained" color="primary">
          {story ? 'Update Story' : 'Add Story'}
        </Button>
      </Box>
    </Box>
  );
};

export default StoryForm;
