import React from 'react';
import { Box, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, IconButton } from '@mui/material';
import { Edit, Delete } from '@mui/icons-material';

const StoryTable = ({ onEdit, onDelete, stories }) => {
  return (
    <Box p={3}>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Story ID</TableCell>
              <TableCell>Story Text</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {stories.map((story) => (
              <TableRow key={story.storyId}>
                <TableCell>{story.storyId}</TableCell>
                <TableCell>{story.storyText}</TableCell>
                <TableCell>
                  <IconButton onClick={() => onEdit(story)}>
                    <Edit />
                  </IconButton>
                  <IconButton edge="end" onClick={() => onDelete(story.storyId)}>
                    <Delete />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
};

export default StoryTable;
