const cartItems = [
    {
        id: '1',
        title: 'Little Krishna',
        price: '399.99',
        img: 'https://m.media-amazon.com/images/I/51k0rSsSZ0L._SX342_SY445_.jpg',
        amount: 1,
    },
    {
        id: '2',
        title: 'Agbar and Birbal',
        price: '195',
        img: 'https://m.media-amazon.com/images/I/615SaD9oHTL._SY445_SX342_.jpg',
        amount: 1,
    },
    {
        id: '3',
        title: 'The Rich Man and the Monkey ',
        price: '699.99',
        img: 'https://cdn-jdbfh.nitrocdn.com/XTbOLvleLvLTNFoFUdqUzTQBhtILBLqa/assets/images/optimized/rev-4a653e8/idriesshahfoundation.org/wp-content/uploads/2024/05/childrensbook_TheRichManAndTheMonkey.png',
        amount: 1,
    },
    {
        id: '5',
        title: '108 Panchatantra Stories Book',
        price: '599.99',
        img: 'https://cdn.fcglcdn.com/brainbees/images/products/438x531/17974310a.webp',
        amount: 1,
    },
  ];
  export default cartItems;
  