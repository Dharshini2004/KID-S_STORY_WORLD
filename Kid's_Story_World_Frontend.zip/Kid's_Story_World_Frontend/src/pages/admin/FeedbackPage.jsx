import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';
import FeedbackTable from '../../components/admin/feedback/FeedbackTable';
import axios from 'axios';
import Sidebar from '../../components/admin/Sidebar';

const FeedbackPage = () => {
  const [feedbacks, setFeedbacks] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch feedbacks from the database when the component mounts
  useEffect(() => {
    const fetchFeedbacks = async () => {
      const token = localStorage.getItem('token');

      try {
        const response = await axios.get('http://localhost:8080/api/feedback/get', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setFeedbacks(response.data);
        console.log(response.data);
      } catch (error) {
        console.error('Error fetching feedbacks:', error);
        alert('Failed to fetch feedbacks.');
      }
    };

    fetchFeedbacks();
  }, []);

  const handleDeleteFeedback = async (feedbackId) => {
    const token = localStorage.getItem('token');

    try {
      await axios.delete(`http://localhost:8080/api/feedback/delete/${feedbackId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setFeedbacks(feedbacks.filter((feedback) => feedback.feedbackId !== feedbackId));
    } catch (error) {
      console.error('Error deleting feedback:', error);
      alert('Failed to delete feedback.');
    }
  };

  return (
    <>
    <Sidebar/>
      <Box sx={{ display: 'flex', flexDirection: 'column', p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h4">Feedbacks</Typography>
        </Box>
        <FeedbackTable feedbacks={feedbacks} onDelete={handleDeleteFeedback} />
        <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <Box
            position="absolute"
            top="10%"
            left="10%"
            right="10%"
            bottom="10%"
            overflow="auto"
            bgcolor="background.paper"
            boxShadow={24}
            p={4}
            borderRadius={2}
          >
            {/* Optionally, you can add a form or more details here */}
          </Box>
        </Modal>
      </Box>
    </>
  );
};

export default FeedbackPage;
