import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import BookForm from '../../components/admin/book/BookForm';
import axios from 'axios';

const UpdateBookPage = ({ onUpdateBook }) => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchBook = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get(`http://localhost:8080/api/books/get/${id}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setBook(response.data);
      } catch (err) {
        setError('Failed to fetch book details.');
        console.error('Error fetching book:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchBook();
  }, [id]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  if (!book) {
    return <div>Book not found.</div>;
  }

  return <BookForm onSubmit={onUpdateBook} book={book} />;
};

export default UpdateBookPage;


// import React from 'react';
// import { useParams } from 'react-router-dom';
// import BookForm from '../../components/admin/book/BookForm';


// const UpdateBookPage = ({ books, onUpdateBook }) => {
//   const { id } = useParams();
//   const book = books.find((b) => b.id === parseInt(id));
//   return <BookForm onSubmit={onUpdateBook} book={book} />;
// };

// export default UpdateBookPage;
