


import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';
import UserTable from '../../components/admin/user/UserTable';
import UserForm from '../../components/admin/user/UserForm';
import Sidebar from '../../components/admin/Sidebar';
import axios from 'axios';

const ManageUsersPage = () => {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch users from the database when the component mounts
  useEffect(() => {
    const fetchUsers = async () => {
      const token = localStorage.getItem('token');
      try {
        const response = await axios.get('http://localhost:8080/api/user/get', {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        // console.log('Fetched users:', response.data); // Verify data here
        if (Array.isArray(response.data)) {
          setUsers(response.data);
        } else {
          console.error('Unexpected data format:', response.data);
        }
      } catch (error) {
        console.error('Error fetching users:', error);
        alert('Failed to fetch users.');
      }
    };
  
    fetchUsers();
  }, []);
  
  useEffect(() => {
    // console.log('Updated users:', users);
  }, [users]);

  const handleAddOrUpdateUser = async (user) => {
    const token = localStorage.getItem('token');

    try {
      let response;
      if (user.userId) {
        // Update existing user
        response = await axios.put(`http://localhost:8080/api/user/put/${user.userId}`, user, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setUsers(users.map((u) => (u.userId === user.userId ? response.data : u)));
      } else {
        // Add new user
        response = await axios.post('http://localhost:8080/api/user/add', user, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setUsers([...users, response.data]);
      }
    } catch (error) {
      console.error('Error adding/updating user:', error);
      alert('Failed to add/update user.');
    }

    setIsModalOpen(false);
  };

  const handleEditUser = (user) => {
    setCurrentUser(user);
    setIsModalOpen(true);
  };

  const handleDeleteUser = async (userId) => {
    const token = localStorage.getItem('token');

    try {
      await axios.delete(`http://localhost:8080/api/user/delete/${userId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setUsers(users.filter((user) => user.userId !== userId));
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Failed to delete user.');
    }
  };

  const handleAddNewUser = () => {
    setCurrentUser(null);
    setIsModalOpen(true);
  };

  return (
    <>
      <Sidebar />
      <Box sx={{ display: 'flex', flexDirection: 'column', marginLeft: { xs: 0, md: '240px' }, p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h4">Users</Typography>
          <Button variant="contained" color="primary" onClick={handleAddNewUser}>
            Add User
          </Button>
        </Box>
        <UserTable onEdit={handleEditUser} onDelete={handleDeleteUser} users={users} />
        <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <Box
            position="absolute"
            top="10%"
            left="10%"
            right="10%"
            bottom="10%"
            overflow="auto"
            bgcolor="background.paper"
            boxShadow={24}
            p={4}
            borderRadius={2}
          >
            <UserForm onSubmit={handleAddOrUpdateUser} user={currentUser} />
          </Box>
        </Modal>
      </Box>
    </>
  );
};

export default ManageUsersPage;
