import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Modal } from '@mui/material';

import Sidebar from '../../components/admin/Sidebar';
import axios from 'axios';
import StoryTable from '../../components/admin/story/StoryTable';
import StoryForm from '../../components/admin/story/StoryForm';

const StoryPage = () => {
  const [stories, setStories] = useState([]);
  const [currentStory, setCurrentStory] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bookId, setBookId] = useState(null); // Assume bookId is available

  useEffect(() => {
    const fetchStories = async () => {
      const token = localStorage.getItem('token');

      try {
        const response = await axios.get(`http://localhost:8080/api/story/get/${bookId}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStories(response.data);
      } catch (error) {
        console.error('Error fetching stories:', error);
        alert('Failed to fetch stories.');
      }
    };

    if (bookId) {
      fetchStories();
    }
  }, [bookId]);

  const handleAddStory = async (story) => {
    const token = localStorage.getItem('token');

    try {
      let response;
      if (story.storyId) {
        // Update existing story
        response = await axios.put(`http://localhost:8080/api/story/put/${story.storyId}`, story, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStories(stories.map((s) => (s.storyId === story.storyId ? response.data : s)));
      } else {
        // Add new story
        response = await axios.post(`http://localhost:8080/api/story/add`, { ...story, bookId }, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStories([...stories, response.data]);
      }
    } catch (error) {
      console.error('Error adding/updating story:', error);
      alert('Failed to add/update story.');
    }

    setIsModalOpen(false);
  };

  const handleEditStory = (story) => {
    setCurrentStory(story);
    setIsModalOpen(true);
  };

  const handleDeleteStory = async (storyId) => {
    const token = localStorage.getItem('token');

    try {
      await axios.delete(`http://localhost:8080/api/story/delete/${storyId}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setStories(stories.filter((story) => story.storyId !== storyId));
    } catch (error) {
      console.error('Error deleting story:', error);
      alert('Failed to delete story.');
    }
  };

  const handleAddNewStory = () => {
    setCurrentStory(null);
    setIsModalOpen(true);
  };

  return (
    <>
      <Sidebar />
      <Box sx={{ display: 'flex', flexDirection: 'column', marginLeft: { xs: 0, md: '240px' }, p: 3 }}>
        <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
          <Typography variant="h4">Stories</Typography>
          <Button variant="contained" color="primary" onClick={handleAddNewStory}>
            Add Story
          </Button>
        </Box>
        <StoryTable onEdit={handleEditStory} onDelete={handleDeleteStory} stories={stories} />
        <Modal open={isModalOpen} onClose={() => setIsModalOpen(false)}>
          <Box
            position="absolute"
            top="10%"
            left="10%"
            right="10%"
            bottom="10%"
            overflow="auto"
            bgcolor="background.paper"
            boxShadow={24}
            p={4}
            borderRadius={2}
          >
            <StoryForm onSubmit={handleAddStory} story={currentStory} />
          </Box>
        </Modal>
      </Box>
    </>
  );
};

export default StoryPage;
