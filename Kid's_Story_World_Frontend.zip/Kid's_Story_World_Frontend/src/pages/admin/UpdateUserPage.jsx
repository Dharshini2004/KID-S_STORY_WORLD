// UpdateUserPage.jsx
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams} from 'react-router-dom';

const UpdateUserPage = () => {
    const { userId } = useParams();
    const [user, setUser] = useState({
        name: '',
        email: '',
    });


    useEffect(() => {
        // Fetch the user data by ID
        axios.get(`/api/users/${userId}`)
            .then(response => {
                setUser(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the user data!', error);
            });
    }, [userId]);

    const handleInputChange = (event) => {
        const { name, value } = event.target;
        setUser({ ...user, [name]: value });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        // Update user data
        axios.put(`/api/users/${userId}`, user)
            .then(response => {
                alert('User updated successfully!');
                history.push('/admin/manage-users');
            })
            .catch(error => {
                console.error('There was an error updating the user!', error);
            });
    };

    return (
        <div>
            <h2>Update User</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={user.name}
                        onChange={handleInputChange}
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={user.email}
                        onChange={handleInputChange}
                    />
                </div>
                <button type="submit">Update</button>
            </form>
        </div>
    );
};

export default UpdateUserPage;


// import React, { useState, useEffect } from 'react';
// import { useParams } from 'react-router-dom';
// import UserForm from '../../components/admin/user/UserForm';
// import axios from 'axios';

// const UpdateUserPage = ({ onUpdateUser }) => {
//   const { id } = useParams();
//   const [user, setUser] = useState(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     const fetchUser = async () => {
//       const token = localStorage.getItem('token');
//       try {
//         const response = await axios.get(`http://localhost:8080/api/user/get/${id}`, {
//           headers: {
//             Authorization: `Bearer ${token}`,
//           },
//         });
//         setUser(response.data);
//       } catch (err) {
//         setError('Failed to fetch user details.');
//         console.error('Error fetching user:', err);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchUser();
//   }, [id]);

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   if (error) {
//     return <div>{error}</div>;
//   }

//   if (!user) {
//     return <div>User not found.</div>;
//   }

//   return <UserForm onSubmit={onUpdateUser} user={user} />;
// };

// export default UpdateUserPage;
