// import React, { useState, useEffect } from 'react';
// import { Typography, Container } from '@mui/material';
// import Quiz from '../components/Quiz';
// import ReadAloud from '../components/ReadAloud';
// import axios from 'axios';
// import { useParams } from 'react-router-dom';

// const Story = () => {
//   const { id } = useParams(); // Assuming you're passing the story ID as a route parameter
//   const [storyData, setStoryData] = useState(null);
//   const [quizzes, setQuizzes] = useState([]); // Initialize as empty array
//   const [selectedAnswers, setSelectedAnswers] = useState({});
//   const [showAnswers, setShowAnswers] = useState({});

//   useEffect(() => {
//     const fetchData = async () => {
//       try {
//         const token = localStorage.getItem("token");
//         if (!token) {
//           console.error("Token not found in localStorage");
//           return;
//         }

//         // Fetch story data
//         const storyResponse = await axios.get(
//           `http://localhost:8080/api/story/get/${id}`,
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         setStoryData(storyResponse.data);

//         // Fetch quiz data
//         const quizResponse = await axios.get(
//           `http://localhost:8080/api/quiz/get/${id}`, // Replace with actual endpoint if available
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         console.log(id);
//         setQuizzes(quizResponse.data || []); // Ensure quizzes is an array

//       } catch (error) {
//         console.error('Error fetching data:', error);
//       }
//     };

//     fetchData();
//   }, [id]);

//   const checkAnswer = (quizIndex, option) => {
//     const isCorrect = quizzes[quizIndex]?.answer === option;
//     setSelectedAnswers({
//       ...selectedAnswers,
//       [quizIndex]: { option, isCorrect }
//     });
//   };

//   const handleShowAnswer = (index) => {
//     setShowAnswers({
//       ...showAnswers,
//       [index]: true
//     });
//   };

//   const maintext = {
//     textAlign: "center",
//     color: "#FF5722", // Bright color
//     fontSize: 40,
//     fontFamily: "'Comic Sans MS', cursive, sans-serif", // Playful font
//     fontWeight: 700,
//     padding: "0px 0px",
//     background: "linear-gradient(90deg, rgba(255,215,0,1) 0%, rgba(255,0,150,1) 100%)", // Gradient background
//     WebkitBackgroundClip: "text",
//     WebkitTextFillColor: "transparent",
//     textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
//     // paddingTop: "50px"
//   };

//   if (!storyData) {
//     return <Typography variant="h5">Loading...</Typography>;
//   }

//   return (
//     <>
//       <Typography variant="h4" gutterBottom sx={maintext}>{storyData.title}</Typography>
//       <Typography variant="h6" gutterBottom sx={{ fontFamily: "Raleway", fontSize: 30 }}>By: {storyData.author}</Typography>
//       <Typography variant="body1" gutterBottom sx={{ fontFamily: "Raleway", fontSize: 20, fontWeight: 20 }}>{storyData.storyText}</Typography>
      
//       <ReadAloud text={storyData.storyText} />

//       <Container sx={{ width: "70%" }}>
//         {quizzes.length > 0 ? (
//           quizzes.map((quiz, index) => (
//             <Quiz
//               key={index}
//               quiz={quiz}
//               quizIndex={index}
//               checkAnswer={checkAnswer}
//               selectedAnswers={selectedAnswers}
//               showAnswers={showAnswers}
//               handleShowAnswer={handleShowAnswer}
//             />
//           ))
//         ) : (
//           <Typography variant="h6">No quizzes available.</Typography>
//         )}
//       </Container>
//     </>
//   );
// };

// export default Story;


import React, { useState, useEffect } from 'react';
import { Typography, Container } from '@mui/material';
import Quiz from '../components/Quiz';
import ReadAloud from '../components/ReadAloud';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const Story = () => {
  const { id } = useParams(); // Assuming you're passing the story ID as a route parameter
  const [storyData, setStoryData] = useState(null);
  const [selectedAnswers, setSelectedAnswers] = useState({});
  const [showAnswers, setShowAnswers] = useState({});

  useEffect(() => {
    const fetchStory = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("Token not found in localStorage");
          return;
        }

        const response = await axios.get(
          `http://localhost:8080/api/story/get/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setStoryData(response.data);
      } catch (error) {
        console.error('Error fetching story:', error);
      }
    };

    fetchStory();
  }, [id]);

  const checkAnswer = (quizIndex, option) => {
    const isCorrect = quizData.quizzes[quizIndex].answer === option;
    setSelectedAnswers({
      ...selectedAnswers,
      [quizIndex]: { option, isCorrect }
    });
  };

  const handleShowAnswer = (index) => {
    setShowAnswers({
      ...showAnswers,
      [index]: true
    });
  };

  const quizData = {
      title: "The Adventures of Timmy",
      author: "Jane Doe",
      story: "Once upon a time, in a clear blue pond, lived a brave little turtle named Timmy. Timmy loved to explore the world around him, but he was always cautious. One sunny day, he saw a butterfly struggling in the water. Without a second thought, Timmy swam to the butterfly and helped it onto a lily pad. The butterfly thanked Timmy and promised to always be his friend. From that day on, they explored the pond together, discovering new places and meeting new friends. Timmy realized that bravery comes in all sizes, and his heart swelled with happiness. The end.",
      quizzes: [
        {
          question: "What kind of animal is Timmy?",
          options: ["A squirrel", "A rabbit", "A fox", "A bear"],
          answer: "A squirrel"
        },
        {
          question: "Where did Timmy live?",
          options: ["In a tree", "In a cave", "In a house", "In a burrow"],
          answer: "In a tree"
        },
        {
          question: "What did Timmy find?",
          options: ["A treasure", "A friend", "A toy", "A map"],
          answer: "A treasure"
        },
        {
          question: "Who helped Timmy?",
          options: ["A rabbit", "A fox", "A bear", "A bird"],
          answer: "A bird"
        },
        {
          question: "What did Timmy learn?",
          options: ["To be brave", "To be kind", "To be honest", "To be careful"],
          answer: "To be brave"
        }
      ]
    };
  const maintext = {
    textAlign: "center",
    color: "#FF5722", // Bright color
    fontSize: 40,
    fontFamily: "'Comic Sans MS', cursive, sans-serif", // Playful font
    fontWeight: 700,
    padding: "0px 0px",
    background: "linear-gradient(90deg, rgba(255,215,0,1) 0%, rgba(255,0,150,1) 100%)", // Gradient background
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent",
    textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
    // paddingTop: "50px"
  };

  if (!storyData) {
    return <Typography variant="h5">Loading...</Typography>;
  }

  return (
    <>
      <Typography variant="h4" gutterBottom sx={maintext}>{storyData.title}</Typography>
      {/* <Typography variant="h6" gutterBottom sx={{fontFamily: "Raleway", fontSize: 30}}>By: {storyData.author}</Typography> */}
      <Typography variant="body1" gutterBottom sx={{fontFamily: "Raleway", fontSize: 20, fontWeight: 20}}>{storyData.storyText}</Typography>
      
      <ReadAloud text={storyData.storyText} />

      <Container sx={{ width: "70%" }}>
        {quizData.quizzes.map((quiz, index) => (
          <Quiz
            key={index}
            quiz={quiz}
            quizIndex={index}
            checkAnswer={checkAnswer}
            selectedAnswers={selectedAnswers}
            showAnswers={showAnswers}
            handleShowAnswer={handleShowAnswer}
          />
        ))}
      </Container>
    </>
  );
};

export default Story;


// import React, { useState } from 'react';
// import { Typography, Container } from '@mui/material';
// import Quiz from '../components/Quiz';
// import ReadAloud from '../components/ReadAloud';


// // const storyData = {
// //   title: "The Adventures of Timmy",
// //   author: "Jane Doe",
// //   story: "Once upon a time, in a clear blue pond, lived a brave little turtle named Timmy. Timmy loved to explore the world around him, but he was always cautious. One sunny day, he saw a butterfly struggling in the water. Without a second thought, Timmy swam to the butterfly and helped it onto a lily pad. The butterfly thanked Timmy and promised to always be his friend. From that day on, they explored the pond together, discovering new places and meeting new friends. Timmy realized that bravery comes in all sizes, and his heart swelled with happiness. The end.",
// //   quizzes: [
// //     {
// //       question: "What kind of animal is Timmy?",
// //       options: ["A squirrel", "A rabbit", "A fox", "A bear"],
// //       answer: "A squirrel"
// //     },
// //     {
// //       question: "Where did Timmy live?",
// //       options: ["In a tree", "In a cave", "In a house", "In a burrow"],
// //       answer: "In a tree"
// //     },
// //     {
// //       question: "What did Timmy find?",
// //       options: ["A treasure", "A friend", "A toy", "A map"],
// //       answer: "A treasure"
// //     },
// //     {
// //       question: "Who helped Timmy?",
// //       options: ["A rabbit", "A fox", "A bear", "A bird"],
// //       answer: "A bird"
// //     },
// //     {
// //       question: "What did Timmy learn?",
// //       options: ["To be brave", "To be kind", "To be honest", "To be careful"],
// //       answer: "To be brave"
// //     }
// //   ]
// // };


// const Story = () => {
//   const [selectedAnswers, setSelectedAnswers] = useState({});
//   const [showAnswers, setShowAnswers] = useState({});

//   const checkAnswer = (quizIndex, option) => {
//     const isCorrect = storyData.quizzes[quizIndex].answer === option;
//     setSelectedAnswers({
//       ...selectedAnswers,
//       [quizIndex]: { option, isCorrect }
//     });
//   };

//   const handleShowAnswer = (index) => {
//     setShowAnswers({
//       ...showAnswers,
//       [index]: true
//     });
//   };
  
// const maintext={
//   textAlign: "center",
//   color: "#FF5722", // Bright color
//   fontSize: 40,
//   fontFamily: "'Comic Sans MS', cursive, sans-serif", // Playful font
//   fontWeight: 700,
//   padding: "0px 0px",
//   background: "linear-gradient(90deg, rgba(255,215,0,1) 0%, rgba(255,0,150,1) 100%)", // Gradient background
//   WebkitBackgroundClip: "text",
//   WebkitTextFillColor: "transparent",
//   textShadow: "2px 2px 4px rgba(0,0,0,0.3)",
//   // paddingTop: "50px"
// }
//   return (
//     <>
    
   
//       <Typography variant="h4" gutterBottom sx={maintext}>{storyData.title}</Typography>
//       <Typography variant="h6" gutterBottom sx={{fontFamily: "Raleway",fontSize:30}}>By: {storyData.author} </Typography>
//       <Typography variant="body1" gutterBottom sx={{fontFamily: "Raleway",fontSize:20,fontWeight:20}}>{storyData.story}</Typography>
      
//       <ReadAloud text={storyData.story} />

//       <Container sx={{width:"70%"}}>
//       {storyData.quizzes.map((quiz, index) => (
//         <Quiz
//           key={index}
//           quiz={quiz}
//           quizIndex={index}
//           checkAnswer={checkAnswer}
//           selectedAnswers={selectedAnswers}
//           showAnswers={showAnswers}
//           handleShowAnswer={handleShowAnswer}
//         />
//       ))}
//     </Container>
//     </>
//   );
// };

// export default Story;

